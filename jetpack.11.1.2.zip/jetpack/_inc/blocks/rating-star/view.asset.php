<?php return array('dependencies' => array('wp-polyfill'), 'version' => 'd175de9b17e6c8bae1c9');
