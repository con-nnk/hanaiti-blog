<?php return array('dependencies' => array('wp-polyfill'), 'version' => 'df04085d71af4a48bf7c');
