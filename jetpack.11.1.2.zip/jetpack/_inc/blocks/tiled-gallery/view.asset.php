<?php return array('dependencies' => array('wp-dom-ready', 'wp-polyfill'), 'version' => 'ea7846cf500bbef097c6');
