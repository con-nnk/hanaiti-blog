<?php return array('dependencies' => array('wp-polyfill'), 'version' => 'ec2a29dec9ff96cca460');
