<?php return array('dependencies' => array('wp-dom-ready', 'wp-polyfill'), 'version' => '0ec6215d4b83b003c971');
