<?php return array('dependencies' => array('wp-polyfill'), 'version' => '005e1146799039d94cbe');
