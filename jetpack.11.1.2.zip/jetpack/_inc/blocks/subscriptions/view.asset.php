<?php return array('dependencies' => array('wp-polyfill'), 'version' => '8bfbb10efdda996e39f3');
