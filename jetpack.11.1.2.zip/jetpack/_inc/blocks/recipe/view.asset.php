<?php return array('dependencies' => array('wp-dom-ready', 'wp-polyfill'), 'version' => 'e4e592161826d7570964');
