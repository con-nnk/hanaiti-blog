<?php return array('dependencies' => array('wp-dom-ready', 'wp-polyfill'), 'version' => '1db0f80499c84469841f');
