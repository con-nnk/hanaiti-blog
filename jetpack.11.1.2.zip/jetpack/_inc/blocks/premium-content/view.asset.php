<?php return array('dependencies' => array('wp-polyfill'), 'version' => '7ac96f7ec9c608912af7');
