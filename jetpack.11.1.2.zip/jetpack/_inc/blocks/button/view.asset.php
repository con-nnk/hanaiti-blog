<?php return array('dependencies' => array('wp-polyfill'), 'version' => '628e1156710e7b64019f');
